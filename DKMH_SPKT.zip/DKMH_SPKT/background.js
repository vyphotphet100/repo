if (document.body.textContent.includes("The service is unavailable") ||
	document.body.textContent.includes("ERR_CONNECTION_TIMED_OUT") ||
	document.body.textContent.includes("available") ||
	document.body.textContent.includes("Lỗi hệ thống mạng") ||
	document.body.textContent.includes("error")) {
  location.reload();
}




