function autoGolike() {

if (window.location.href.indexOf("load_job") != -1 && 
	document.body.innerHTML.indexOf("Đã gửi thông tin lên hệ thống xét duyệt") == -1 &&
	document.body.innerHTML.indexOf("Network Error") == -1) {
	// Click vao nhiem vu o man hinh chinh
	if (document.body.innerHTML.indexOf("Còn lại") != -1 &&
		document.getElementsByClassName("row align-items-center")[8] != null)
		document.getElementsByClassName("row align-items-center")[8].click();
}


// Click vao Trinh duyet khi o trang Chi tiet
if (window.location.href.indexOf("job-detail") != -1 &&
	window.location.href.indexOf("done") == -1) {
	if (document.body.innerHTML.indexOf("Làm việc bằng trình duyệt Web trên điện thoại") &&
		document.getElementsByClassName("material-icons font-light font-24")[1] != null) {

		document.getElementsByClassName("row align-items-center")[2].target = "_self";
		if (document.body.innerHTML.indexOf("TĂNG LIKE CHO FANPAGE") != -1) {
			document.getElementsByClassName("row align-items-center")[2].href += "?likefanpage";
		}
						
		else if (document.body.innerHTML.indexOf("TĂNG LIKE CHO BÀI VIẾT") != -1) 
			document.getElementsByClassName("row align-items-center")[2].href += "?likebaiviet";

		document.getElementsByClassName("material-icons font-light font-24")[1].click();
	}
		
}

// Click Thich bai viet o trang fb
if (window.location.href.indexOf("www.facebook.com") != -1)
	window.location.href = window.location.href.replace("www", "mbasic") + "";

if (window.location.href.indexOf("mbasic.facebook.com") != -1) {
	// Like fanpage	
	if (window.location.href.indexOf("likefanpage") != -1) {
			if (document.body.outerHTML.indexOf('/a/profile.php') != -1) {
			var linkLike = "";
			for (var i=document.body.outerHTML.indexOf('/a/profile.php'); document.body.outerHTML[i] != '"'; i++)
				linkLike += "" + document.body.outerHTML[i] + "";
			linkLike = linkLike.replaceAll("amp;", "");

			window.location.href = "https://mbasic.facebook.com" + linkLike;
		} 
		else 
			window.location.href = window.location.href + "_rdr";
	} 
	// Like bai viet
	else if (window.location.href.indexOf("likebaiviet") != -1) {
		if (document.body.outerHTML.indexOf('/a/like.php') != -1) {
			var linkLike = "";
			for (var i=document.body.outerHTML.indexOf('/a/like.php'); document.body.outerHTML[i] != '"'; i++)
				linkLike += "" + document.body.outerHTML[i] + "";
			linkLike = linkLike.replaceAll("amp;", "");

			window.location.href = "https://mbasic.facebook.com" + linkLike;
		} 
		else 
			window.location.href = window.location.href + "_rdr";
	}
	else 
			window.location.href = window.location.href + "_rdr";

	if (window.location.href.indexOf("_rdr") != -1){
		window.location.href = "https://app.golike.net/jobs/facebook/job-detail?job=like?done";
	}
}

// Xu ly khi da hoan thanh job
if (window.location.href.indexOf("job-detail") != -1 &&
	window.location.href.indexOf("done") != -1) {

	document.getElementsByClassName("row align-items-center")[2].href = "#";
	document.getElementsByClassName("row align-items-center")[2].target = "_self";
	document.getElementsByClassName("material-icons font-light font-24")[1].click();

	setTimeout(function() {
		if (document.body.innerHTML.indexOf('id="captcha-golike" tabindex="-1" role="dialog" aria-labelledby="edit" class="modal show" aria-modal="true" style="display: block;">') == -1){
			if (document.getElementsByClassName("font-bold font-18")[5].outerText == "Hoàn thành")
				document.getElementsByClassName("font-bold font-18")[5].click();
			else 
				document.getElementsByClassName("font-bold font-18")[6].click();
		}
		
	}, 5500);


	if (document.body.innerHTML.indexOf('Hệ thống kiểm tra thấy bạn chưa thực hiện thao tác') != -1) {
		document.getElementsByClassName("btn btn-primary btn-sm form-control mt-3")[0].click();
	}
	
}

// Click Ok khi Thanh cong 
if (window.location.href.indexOf("load_job") != -1) {
	// Click vao nhiem vu o man hinh chinh
	if (document.getElementsByClassName("swal2-confirm swal2-styled")[0] != null)
		document.getElementsByClassName("swal2-confirm swal2-styled")[0].click();
}

}  





if (window.location.href.indexOf("facebook.com") != -1)
	autoGolike();
else {
	setInterval(function() {
		if (document.getElementsByClassName("row align-items-center loading-news")[0] == null) {
			autoGolike();
		}
	}, 1000);

}



