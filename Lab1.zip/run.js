//3. Program and measure the execution time of 05 sorting methods on your computer.
"use strict";
function swap(a, b) {
    return [b, a];
}

// bubble sort
function bubbleSort() {
    console.time('Execution Time');
 
    // task starts
    var step = 0;
    var arr = [5,4,7,2,8,6,4,9,2];
    for (var i=0; i<arr.length-1; i++) {
        for (var j=0; j<=arr.length-1-i; j++) {
            if (arr[j+1] < arr[j]) {
                [arr[j+1], arr[j]] = swap(arr[j+1], arr[j]);
                step++;
            }
        }
    }

    console.log("Bubble sort:");
    console.log(arr);
    console.log("Execution steps: " + step);
    // task ends
    
    console.timeEnd('Execution Time');   
}

function interchangeSort() {
    console.time('Execution Time');

    let step = 0;
    let arr = [5,4,7,2,8,6,4,9,2];
    for (let i=0; i<arr.length-1; i++) {
        for (let j=i+1; j<arr.length; j++){
            if (arr[i] > arr[j]) {
                [arr[i], arr[j]] = swap(arr[i], arr[j]);
                step++;
            }
        }
    }
    console.log("Interchange sort: ");
    console.log(arr);
    console.log("Execution steps: " + step);

    console.timeEnd('Execution Time');
}

function selectionSort() {
    console.time('Execution Time');

    let step = 0;
    let arr = [5,4,7,2,8,6,4,9,2];

    for (let i=0; i<arr.length-1; i++) {
        let min = arr[i];
        let idxMin = i;
        for (let j=i+1; j<arr.length; j++) {
            if (arr[j] < min) {
                min = arr[j];
                idxMin = j;
            }
        }

        [arr[i], arr[idxMin]] = swap(arr[i], arr[idxMin]);
    }

    console.log("Selection sort: ");
    console.log(arr);
    console.log("Execution steps: " + step);

    console.timeEnd('Execution Time');
}

function insertionSort() {
    console.time('Execution Time');

    let step = 0;
    let arr = [5,4,7,2,8,6,4,9,2];

    for (let i=0; i<arr.length-1; i++) {
        for (let j=i+1; j<arr.length; j++) {
            let tmpJ = j;
            while (arr[j] < arr[j-1]) {
                [arr[j], arr[j-1]] = swap(arr[j], arr[j-1]);
                j--;
            }
            j = tmpJ;
        }
    }

    console.log("Insertion sort: ");
    console.log(arr);
    console.log("Execution steps: " + step);

    console.timeEnd('Execution Time');

}

// let arr = [5,4,7,2,8,6,4,9,2];
// function mergeSort(arr) {

//     if (arr.length == 2 && arr[0] > arr[1]) {
//         [arr[0], arr[1]] = swap(arr[0], arr[1]);
//         return;
//     }

//     let middle = (arr.length/2).toFixed()-1;
//     let arr1 = [];
//     for (let i=0; i<middle)
// }

bubbleSort();
interchangeSort();
selectionSort();
insertionSort();






